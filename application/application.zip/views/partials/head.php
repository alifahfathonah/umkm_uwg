<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo base_url('assets/vendor/adminlte/') ?>plugins/fontawesome-free/css/all.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="	<?php echo base_url('assets/vendor/adminlte/') ?>dist/css/adminlte.min.css">