<footer class="main-footer">
<strong>2021 <a href="">UMKM - Universitas Widyagama</a>.</strong>
<div class="float-right d-none d-sm-inline-block">
</div>
</footer>